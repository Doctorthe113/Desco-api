# Desco-api
A python library that lets you check balance, check monthly consumption, check daily consumption, last recharge data of your DESCO account.
