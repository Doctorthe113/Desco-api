from desco_api.modules import check_balance
from desco_api.modules import monthly_consumption
from desco_api.modules import daily_consumption
from desco_api.modules import last_recharge